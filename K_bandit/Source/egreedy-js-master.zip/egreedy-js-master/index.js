module.exports = require('./lib/Algorithm');
