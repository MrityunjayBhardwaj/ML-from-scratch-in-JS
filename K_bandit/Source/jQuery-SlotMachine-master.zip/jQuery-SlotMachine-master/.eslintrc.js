module.exports = {
  extends: 'standard',
  env: {
    jquery: true,
    browser: true
  },
  rules: {
    semi: 0,
    'no-unused-expressions': 1
  }
}
